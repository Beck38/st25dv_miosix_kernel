
This is an example of how to develop a Miosix program in assembler
(for Cortex-M3) instead of C/C++.

To run this example, copy the content of this directory into
the top level directory, and modify the Makefile from 

SRC :=                                  \
main.cpp

to

SRC :=                                  \
main.s