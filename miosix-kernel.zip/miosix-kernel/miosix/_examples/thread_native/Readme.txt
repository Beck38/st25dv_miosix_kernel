
To run this example, copy the content of this directory into
the top level directory, and modify the Makefile from 

SRC :=                                  \
main.cpp

to

SRC :=                                  \
native_thread_example.cpp