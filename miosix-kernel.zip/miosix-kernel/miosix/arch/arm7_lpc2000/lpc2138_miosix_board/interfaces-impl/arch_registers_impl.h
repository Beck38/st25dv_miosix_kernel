
#ifndef ARCH_REGISTERS_IMPL_H
#define	ARCH_REGISTERS_IMPL_H

#include "LPC213x.h"

#endif	//ARCH_REGISTERS_IMPL_H
