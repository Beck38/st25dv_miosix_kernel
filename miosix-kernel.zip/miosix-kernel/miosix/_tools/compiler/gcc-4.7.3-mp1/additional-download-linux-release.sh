#!/bin/sh

# This simple script will download additional surces required to make a
# distributable release build for linux

wget http://mirror2.mirror.garr.it/mirrors/gnuftp/gnu/ncurses/ncurses-5.9.tar.gz
wget http://megastep.org/makeself/makeself-2.1.5.run
