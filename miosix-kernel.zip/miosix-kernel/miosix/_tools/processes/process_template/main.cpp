
#include <cstdio>
// #include <iostream>

using namespace std;

int main()
{
    printf("Hello world\n");
//     cout << "Hello world" << endl;
    return 0;
}
