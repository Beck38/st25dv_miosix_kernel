#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>

int main()
{
	//This process sleeps for 5 seconds;
	usleep(5000000);
	return 0;
}
