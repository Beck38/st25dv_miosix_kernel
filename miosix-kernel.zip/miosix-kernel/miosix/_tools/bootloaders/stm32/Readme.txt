This bootloader works for the following boards:
-stm3210e-eval
-stm3220g-eval

see miosix/doc/textdoc/stm32-bootloader.txt